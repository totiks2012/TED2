#!/bin/bash
cd /home/live/DEV/FOR_PUBLICATIONS-marcus-ted2+-09-05-25/TED2+_Pub/
nohup wish ./main-core-1_1.tcl &
